/*
Author: Ismail Fauzi Isnin
Date: 12 May 2014
*/

#include <iostream>
#include "Employee.h"

using namespace std;

int main()
{
  
  Employee emp1("Susan Mayers", 47899, "Accounting", "Vice President");
  

  Employee emp2;  
  Employee* empPtr = &emp2;
  empPtr->setName("Mark Jones");
  empPtr->setId( 39119 );
  empPtr->setDepartment("IT");
  empPtr->setPosition("Programmer");


  Employee* emp3; 
  emp3 = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");
  

  //display content of emp1
  cout << "Employee1's Name: " << emp1.getName() << endl;
  cout << "Employee1's ID: " << emp1.getId() << endl;
  cout << "Employee1's Department: " << emp1.getDepartment() << endl;
  cout << "Employee1's Position: " << emp1.getPosition() << endl << endl;;

  //display content of emp2 (using Employee object)
  cout << "Employee2's Name: " << emp2.getName() << endl;
  cout << "Employee2's ID: " << emp2.getId() << endl;
  cout << "Employee2's Department: " << emp2.getDepartment() << endl;
  cout << "Employee2's Position: " << emp2.getPosition() << endl << endl;


  //display content of empPtr (using Employee pointer)
  cout << "Employee2's Name: " << empPtr->getName() << endl;
  cout << "Employee2's ID: " << empPtr->getId() << endl;
  cout << "Employee2's Department: " << empPtr->getDepartment() << endl;
  cout << "Employee2's Position: " << empPtr->getPosition() << endl << endl;


  //display content of emp3
  cout << "Employee3's Name: " << emp3->getName() << endl;
  cout << "Employee3's ID: " << emp3->getId() << endl;
  cout << "Employee3's Department: " << emp3->getDepartment() << endl;
  cout << "Employee3's Position: " << emp3->getPosition() << endl << endl;
 
  
  delete emp3;  // dont forget to delete dynamically allocated memory.
  

  return 0;
}
