/*
Author: Ismail Fauzi Isnin
Date: 12 May 2014
*/

#include <string>
#include "Employee.h"

//using namespace std;

Employee::Employee()
{
  name = " ";
  idNumber = 0;
  department = " ";
  position = " ";
}



Employee::Employee(string n, int id)
{
  name = n;
  idNumber = id;
  department = " ";
  position = " ";
}


Employee::Employee(string n, int id, string d, string p)
{
  name = n;
  idNumber = id;
  department = d;
  position = p;
}

// mutator
void Employee::setName(string n)
{
  name = n;
}

void  Employee::setId(int id)
{
  idNumber = id;
}

void  Employee::setDepartment(string d)
{
  department = d;
}


void  Employee::setPosition(string p)
{
  position = p;
}


// accessor
string Employee::getName()
{
  return name;
}

int Employee::getId()
{
  return idNumber;
}

string Employee::getDepartment()
{
  return department;
}

string Employee::getPosition()
{
  return position;
}

