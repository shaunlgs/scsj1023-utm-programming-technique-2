/*
Author: Ismail Fauzi Isnin
Date: 12 May 2014
*/

#include <string>

using namespace std;

class Employee{  
  string name;
  int idNumber;
  string department, position;
  
public:
  //constructor
  Employee();
  Employee(string n, int i);
  Employee(string n, int i, string d, string p);

  //mutator
  void setName(string n);
  void setId(int id);
  void setDepartment(string d);
  void setPosition(string p);

  //accessor
  string getName();
  string getDepartment();
  string getPosition();
  int getId();
  
};


